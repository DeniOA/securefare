import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './blank.component.html',
  styleUrls: []
})
export class BlankComponent {}
