import { Component } from '@angular/core';

@Component({
  // selector: 'app-train',
  templateUrl: 'train.component.html',
})
export class TrainComponent {}

