export class Comments {
  id: number;
  device_id: number;
  name: string;
  is_active: string;
  imei: number;
  station: number;
}