export const appConfig = {
    title: 'SecureFare 2019 v1.1',
    clientName: 'Oleander',
    apiUrl: 'http://104.248.174.205/',
    //apiUrl: 'http://139.59.172.79/',
    //apiUrl: 'http://192.168.1.130:3333/',
    //apiUrl: 'http://license.pythonanywhere.com/',
    //apiUrl: 'http://vdl.pythonanywhere.com/',
    //apiUrl: 'http://sidvms.pythonanywhere.com/',
    //apiUrl: 'http://localhost:8000',
    //apiUrl: 'http://projectss.pythonanywhere.com/',
    //apiUrl: 'http://cigbokwe.pythonanywhere.com/',
    //session: 'effectivesales_web_current_session',
    //requestAuthorization: 'token-text' //fill with client basic access token
};