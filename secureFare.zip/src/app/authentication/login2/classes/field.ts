export interface Field {
  username: string;
  password: string;
  email: string;
}
