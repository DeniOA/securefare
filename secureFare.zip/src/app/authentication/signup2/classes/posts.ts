// export class Posts {
//   username: string;
//   password: string;
//   email: string;
//   first_name: string;
//   last_name: string
// }

export interface Registration {
  username: string;
  password: string;
  email: string;
  first_name: string;
  last_name: string;
}
