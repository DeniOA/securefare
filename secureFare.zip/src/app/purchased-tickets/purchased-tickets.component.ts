import { Component } from '@angular/core';

@Component({
  // selector: 'app-purchased-tickets',
  templateUrl: './purchased-tickets.component.html'
})
export class PurchasedTicketsComponent {
  constructor() {
    
  }
}

