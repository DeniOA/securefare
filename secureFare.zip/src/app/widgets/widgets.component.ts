import { Component } from '@angular/core';
import { NgbProgressbarConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  templateUrl: './widgets.component.html'
})
export class WidgetsComponent {
  constructor() {}
}
