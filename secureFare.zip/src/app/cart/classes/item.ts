import { Schedule } from '../../schedule/classes/schedule';

export class Item {

    lstSchedule: Schedule;
    quantity: number;

}

