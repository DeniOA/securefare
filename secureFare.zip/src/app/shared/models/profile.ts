export interface IProfile {
  
    sex: string,
    security_questions: string,
    anaswer: string,
    email: string,
    firstname: string, 
    lastname: string,
    // image: image, //email: editForm.email,
    username:string
 
}