

export class Schedule {
  id:number;
  amount: number;
  passengertype: string;
  train_name: string;
  schedule_i: number;
  schedule_name: string;
  the_day: string;
  arrival: string;
  departure: string;
  ages: string;
  age_id: number;
  train_i: number;
  ticket_class_i: number;
  ticket_class_type: string;
  typeoftrip: string;
  source_terminal: string;
  destination_terminal: string;
  Quantity: number;

}


