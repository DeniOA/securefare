import { Component, OnInit } from '@angular/core';



@Component({
  // selector: 'app-train',
  templateUrl: 'agent.component.html',
})
export class AgentComponent {}
