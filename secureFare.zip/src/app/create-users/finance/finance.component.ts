import { Component, OnInit } from '@angular/core';

@Component({
  // selector: 'app-train',
  templateUrl: 'finance.component.html',
})
export class FinanceComponent {}
