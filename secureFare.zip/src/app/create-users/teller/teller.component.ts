import { Component } from '@angular/core';

@Component({
  // selector: 'app-train',
  templateUrl: 'teller.component.html',
})
export class TellerComponent {}
