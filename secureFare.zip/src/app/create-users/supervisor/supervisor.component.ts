import { Component } from '@angular/core';

@Component({
  // selector: 'app-train',
  templateUrl: 'supervisor.component.html',
})
export class SupervisorComponent {}
