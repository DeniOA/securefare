export class Models {
  source: number;
  destination: number;
  check_date: string;

}