import { Component } from '@angular/core';

@Component({
  // selector: 'app-train',
  templateUrl: 'daily-sales.component.html',
})
export class DailySalesComponent {}
