import { Component } from '@angular/core';

@Component({
  // selector: 'app-train',
  templateUrl: 'e-transactions.component.html',
})
export class ETransactionsComponent {}
