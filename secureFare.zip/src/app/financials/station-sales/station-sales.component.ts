import { Component } from '@angular/core';

@Component({
  // selector: 'app-train',
  templateUrl: 'station-sales.component.html',
})
export class StationSalesComponent {}