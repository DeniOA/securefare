import { Component } from '@angular/core';

@Component({
  // selector: 'app-train',
  templateUrl: 'e-summary.component.html',
})
export class ESummaryComponent {}
