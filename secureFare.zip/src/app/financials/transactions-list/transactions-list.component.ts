import { Component } from '@angular/core';

@Component({
  // selector: 'app-train',
  templateUrl: 'transactions-list.component.html',
})
export class TransactionsListComponent {}
